<div class="container">
    <h1 class="mt-4"></h1>
    <img src="<?= BASEURL; ?>/img/donat-kentang-malang.jpg" width="200" class="rounded-circle">
    <p></p>
    <p></p>

</div>

<div class="container">
<div class="jumbotron mt-4">
  <h1 class="display-4">Selamat Datang di website e-commerce!</h1>
  <p class="lead">Toko Donat Malang <?= $data['nama']; ?></p>
  <hr class="my-4">
  <p>berbagai macam frozen food!! Dan juga promo menarik ada disini^.^</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>


</div>
