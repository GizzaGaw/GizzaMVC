<div class="container mt-5"> 

<div class="card" style="width: 18rem;">
   <div class="card-body">
    <h5 class="card-title"><?= $data['plj']['nama_produk']; ?></h5>
    <h6 class="card-subtitle mb-2 text-muted"><?= $data['plj']['kode_produk'];?></h6>
    <p class="card-text"><?= $data['plj']['harga']; ?></p
    <p class="card-text"><?= $data['plj']['jenis_produk']; ?></p>
    <a href="<?=BASEURL; ?>/produk" class="card-link">kembali</a>
  </div>
</div>

</div>