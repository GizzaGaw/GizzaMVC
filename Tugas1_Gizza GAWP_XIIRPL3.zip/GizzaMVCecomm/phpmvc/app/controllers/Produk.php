<?php

class Produk extends Controller{
    public function index()
    {
        $data['judul']='Daftar Produk';
        $data['plj'] = $this->model('Produk_model')->getAllProduk();
        $this->view('templates/header', $data);
        $this->view('produk/index', $data);
        $this->view('templates/footer');
    }

    public function detail($id)
    {
        $data['judul']='Detail Produk';
        $data['plj'] = $this->model('produk_model')->getProdukByid($id);
        $this->view('templates/header', $data);
        $this->view('produk/detail', $data);
        $this->view('templates/footer');
    }

    public function tambah(){

        if( $this->model('Produk_model')->tambahDataProduk($_POST) > 0 ) {
            flasher::setFlash('berhasil', 'ditambahkan', 'success');
            header('location: ' . BASEURL . '/Produk');
            exit; 
        }  else { flasher::setFlash('gagal', 'ditambahkan', 'danger');
            header('location: ' . BASEURL . '/Produk');
            exit; 
        }
}

    public function hapus($id){

        if( $this->model('Produk_model')->hapusDataProduk($id) > 0 ) {
            flasher::setFlash('berhasil', 'dihapus', 'success');
            header('location: ' . BASEURL . '/Produk');
            exit; 
        }  else { flasher::setFlash('gagal', 'dihapus', 'danger');
            header('location: ' . BASEURL . '/Produk');
            exit; 
        }
}



   public function getubah()
   {
      echo json_encode($this->model('Produk_model')->getProdukById($_POST['id']));
   }

   public function ubah()
   {
    if( $this->model('Produk_model')->ubahDataProduk($_POST) > 0 ) {
        flasher::setFlash('berhasil', 'diubah ', 'success');
        header('location: ' . BASEURL . '/Produk');
        exit; 
    }  else { 
        flasher::setFlash('gagal', 'diubah', 'danger');
        header('location: ' . BASEURL . '/Produk');
        exit; 
    } 
   }

   public function cari()
   {
    $data['judul']='Daftar Produk';
    $data['plj'] = $this->model('Produk_model')->cariDataProduk();
    $this->view('templates/header', $data);
    $this->view('produk/index', $data);
    $this->view('templates/footer');
   }
}