<div class="container">
<div class="jumbotron mt-4">
  <h1 class="display-4">Selamat Datang di website e-commerce!</h1>
  <p class="lead">toko Donat mlng <?= $data['nama']; ?></p>
  <hr class="my-4">
  <p>berbagai macam frozen food!! Dan juga promo menarik ada disini.</p>
  <a class="btn btn-primary btn-lg" href="#" role="button">Learn more</a>
</div>


</div>
