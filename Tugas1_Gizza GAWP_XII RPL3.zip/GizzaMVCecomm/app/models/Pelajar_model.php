<?php

class pelajar_model
{
    private $table = 'produk';
    private $db;

    public function __construct()
    {
        $this->db = new Database;
    }

    public function getAllpelajar()
    {
        $this->db->query('SELECT * FROM ' . $this->table);
        return $this->db->resultset();
    }

    public function getpelajarByid($id)
    {
        $this->db->query("SELECT * FROM `produk` WHERE id = :id");
        $this->db->bind("id", $id);
        return $this->db->single();
    }

    public function tambahDataPelajar($data)
    {
        $query = "INSERT INTO produk 
                   VALUES
                  ('' , :nama produk, :kode produk, :harga, :jenis produk)";

        $this->db->query($query);
        $this->db->bind('nama produk', $data['nama produk']);
        $this->db->bind('kode produk', $data['kode produk']);
        $this->db->bind('harga', $data['harga']);
        $this->db->bind('jenis produk', $data['jenis produk']);

        $this->db->execute();

        return $this->db->rowcount();
    }

    public function hapusDataPelajar($id)
    {
        $query = "DELETE FROM pelajar WHERE id = :id";
        $this->db->query($query);
        $this->db->bind('id', $id);

        $this->db->execute();

        return $this->db->rowCount();
    }
    public function ubahDataPelajar($data)
    {
        $query = "UPDATE produk SET
                  nama produk = :nama produk, 
                  kode produk = :kode produk,
                  harga = :harga,
                  jenis produk = :jenis produk 
                  WHERE id = :id";
    
        $this->db->query($query);
        $this->db->bind('nama produk', $data['nama produk']);
        $this->db->bind('kode produk', $data['kode produk']);
        $this->db->bind('harga', $data['harga']);
        $this->db->bind('jenis produk', $data['jenis produk']);
        $this->db->bind('id', $data['id']);
    
        $this->db->execute();
    
        return $this->db->rowcount();
    }
    public function cariproduk()
    {
       $keyword = $_POST['keyword'];
       $query = "SELECT * FROM produk WHERE nama LIKE :keyword";
       $this->db->query($query);
       $this->db->bind('keyword', "%$keyword%");
       return $this->db->resultset();
  
    }
}