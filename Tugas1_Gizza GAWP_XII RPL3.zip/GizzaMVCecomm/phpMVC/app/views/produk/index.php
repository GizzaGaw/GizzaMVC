<div class="container mt-3">

<div class="row">
  <div class="col-lg-6">
    <?php flasher::flash();?>
  </div>
</div>

<div class="row mb-3">
  <div class="col-lg-6">
  <button type="button" class="btn btn-primary tombolTambahData" data-bs-toggle="modal" data-bs-target="#formModal">
    tambah produk jualan
  </button>
  </div>
</div>

<div class="row mb-3">
  <div class="col-lg-6">
  <form action="<?= BASEURL;?>/produk/cari" method="post">
  <div class="input-group">
  <input type="text" class="form-control" placeholder="cari produk.." name="keyword" id="keyword" autocomplete="off">
  <button class="btn btn-primary" type="submit" id="tombolcari">cari</button>
</div>
</form>
  </div>
</div>

</div class="row">
<div class="col-lg-6">

  <h3>Daftar Produk</h3>
  <ul class="list-group">
    <?php foreach ($data['plj'] as $plj) : ?>
      <li class="list-group-item">
        <?= $plj['nama_produk']; ?>
        <a href="<?= BASEURL; ?>/produk/hapus/<?= $plj['id']; ?>" class="badge bg-danger float-end me-1"  onclick="return confirm('yakin?')">hapus</a>
        <a href="<?= BASEURL; ?>/produk/ubah/<?= $plj['id']; ?>" class="badge bg-warning float-end me-1 tampilModalUbah" data-bs-toggle="modal" data-bs-target="#formModal" data-id="<?=$plj['id']?>">ubah</a>
        <a href="<?= BASEURL; ?>/produk/detail/<?= $plj['id']; ?>" class="badge bg-primary float-end me-1">detail</a>
        


      </li>
    <?php endforeach; ?> 
  </ul>

</div>
</div>

</div>  


<!-- Modal -->
<div class="modal fade" id="formModal" tabindex="-1" aria-labelledby="formModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="formModalLabel">Tambah produk jualan</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">

        <form action="<?= BASEURL; ?>/produk/tambah" method="post">
         <input type="hidden" name="id" id="id"> 
             <div class="form-group">
                 <label for="nama produk">Nama produk</label>
                 <input type="text" class="form-control" id="nama produk" name="nama produk" />
              </div>

          <div class="form-group">
            <label for="nrp">kode produk</label>
            <input type="number" class="form-control" id="kode produk" name="kode produk" />
          </div>


          <div class="form-group">
            <label for="harga">harga</label>
            <input type="varchar" class="form-control" id="harga" name="harga" />
          </div>

          <div class="form-group">
               <label for="jenis produk">jenis produk</label>
                 <select class="form-control" id="jenis produk" name="jenis produk">
                      <option value="makanan frozen">makanan frozen</option>
                 <option value="siap saji">siap saji</option>  
               <option value="makanan ringan">makanan ringan</option>
              <option value="makan viral">makanan viral</option>
                   
            </select>
              </div>




      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Tambah Data</button>
        </form>
      </div>
    </div>
  </div>
    </div>