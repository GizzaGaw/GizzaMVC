<div class="container">
    <h1 class="mt-4">Detail Barang</h1>
    <img src="<?= BASEURL; ?>/img/Donat.jpg" alt="Gizza" class="rounded-circle">
    <p>Donat, kentang 3D donat beku frozen 20pcs</p>

</div>